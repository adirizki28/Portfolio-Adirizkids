/** @type {import('tailwindcss').Config} */
export default {
  content: ["./dist/index.html"],
  theme: {
    extend: {
      fontFamily: {
        clash: ['"Clash Display"', 'sans-serif'],
        jakarta: ['"Plus Jakarta Sans"', 'sans-serif']
      },
    },
  },
  plugins: [],
}
